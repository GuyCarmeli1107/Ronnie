This is the base code needed to get usable angles from a BerryIMU
using connected to a Raspberry Pi Pico, using I2C or SPI

BerryIMUv3 is supported by this code

Feel free to do whatever you like with this code.
Distributed as-is; no warranty is given.

https://ozzmaker.com/berryimu/


